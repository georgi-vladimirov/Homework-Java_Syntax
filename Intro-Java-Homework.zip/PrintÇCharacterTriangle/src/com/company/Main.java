package com.company;
import java.util.Scanner;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int i = input.nextInt();

        for(int c=0; c<i;c++){
            for (int j=97;j<=c+97;j++){
                char symbol = (char)j;
                System.out.print(symbol+ " ");
            }
            System.out.println();
        }
        for(int c=i-1; c>0;c--){
            for (int j=97;j<c+97;j++){
                char symbol = (char)j;
                System.out.print(symbol+ " ");
            }
            System.out.println();
        }
    }
}
