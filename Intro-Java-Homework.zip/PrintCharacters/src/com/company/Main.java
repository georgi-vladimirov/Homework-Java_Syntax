package com.company;

public class Main {

    public static void main(String[] args) {
        for(char symbol='a';symbol<='z';symbol++) {
            System.out.print(symbol + " ");
        }
    }
}
