package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int number = input.nextInt();
        String result = "";
        while (number > 0) {
            int n = number % 10;
            number = number / 10;
            String temp = "";
            switch (n) {
                case 0:
                    temp = "Gee";
                    break;
                case 1:
                    temp = "Bro";
                    break;
                case 2:
                    temp = "Zuz";
                    break;
                case 3:
                    temp = "Ma";
                    break;
                case 4:
                    temp = "Duh";
                    break;
                case 5:
                    temp = "Yo";
                    break;
                case 6:
                    temp = "Dis";
                    break;
                case 7:
                    temp = "Hood";
                    break;
                case 8:
                    temp = "Jam";
                    break;
                case 9:
                    temp = "Mack";
                    break;
            }
            result = temp + result;
        }
        System.out.println(result);
    }
}