package com.company;

public class Main {

    public static void main(String[] args) {

        boolean var1 = false;
        String var2 = "Palo Alto, CA";
        short var3 = 32767;
        int var4 = 2000000000;
        double var5 = 0.1234567891011;
        float var6 = 0.5f;
        long var7 = 919827112351L;
        char var8 = 'c';
    }
}
